# pymodore
Simple pomodore to run in terminal with sound.

A example of log generated from this script:
```
🍅 Begin:03/02/2020 16:04:07 | Learn Python | TIME: 25 minutes
🍅 Begin:03/02/2020 16:05:01 | Hello World | TIME: 25 minutes
🍅 Begin:03/02/2020 16:06:04 | Test interrupt | TIME: 4 minutes
🍅 Begin:03/02/2020 16:06:39 | It worked in my machine | TIME: 25 minutes
|-🍅-🍅- REST -🍅-🍅-|
```
